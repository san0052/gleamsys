<?php 
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

require __DIR__  . '/vendor/autoload.php';

	// After Step 1
	$apiContext = new \PayPal\Rest\ApiContext(
	        new \PayPal\Auth\OAuthTokenCredential(
	            'AZJ_Yg1pnWhNZoC0mZL5zqL-CkAsKn0-r4VBJfetFZfXyD1oCgoS5FDRzi4l1aKhpuUsQEyaXDnld5cw',     // ClientID
	            'EKQfm7HaE1plTmrEtGXGOcwx8zwlFkM23uye3FD5ZLWVoXws7Au4tv0dfOflR0kqvky3hD_fKSGDYtM7'      // ClientSecret
	        )
	);


	// After Step 2
	$payer = new \PayPal\Api\Payer();
	$payer->setPaymentMethod('paypal');

	$amount = new \PayPal\Api\Amount();
	$amount->setTotal('1.00');
	$amount->setCurrency('USD');

	$transaction = new \PayPal\Api\Transaction();
	$transaction->setAmount($amount);

	$redirectUrls = new \PayPal\Api\RedirectUrls();
	$redirectUrls->setReturnUrl("http://localhost/paypal/success.php")
	    ->setCancelUrl("http://localhost/paypal/cancel.php");

	$payment = new \PayPal\Api\Payment();
	$payment->setIntent('sale')
	    ->setPayer($payer)
	    ->setTransactions(array($transaction))
	    ->setRedirectUrls($redirectUrls);


	// After Step 3
	try {
	    $payment->create($apiContext);
	    // echo $payment;

	    // echo "\n\nRedirect user to approval_url: " . $payment->getApprovalLink() . "\n";
	    $approvalUrl = $payment->getApprovalLink();
	    header('Location: '.$approvalUrl);
	}
	catch (\PayPal\Exception\PayPalConnectionException $ex) {
	    // This will print the detailed information on the exception.
	    //REALLY HELPFUL FOR DEBUGGING
	    echo $ex->getData();
	}
?>